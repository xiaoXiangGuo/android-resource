package com.cniao5.cniao5retrofitdemo;

/**
 * Created by Ivan on 2016/10/7.
 */

public class BaseResult {

    private int success;
    private String message;
    private int user_id;

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
