package com.cniao5.cniao5dagger2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.cniao5.cniao5dagger2.user.DaggerUserComponet;
import com.cniao5.cniao5dagger2.user.User;
import com.cniao5.cniao5dagger2.user.UserManger;
import com.cniao5.cniao5dagger2.user.UserModule;

import javax.inject.Inject;
import javax.inject.Singleton;

import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity {






    @Inject User mUser;

    @Inject
    UserManger userManger;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        DaggerUserComponet.builder().userModule(new UserModule())
                .appComponent(((MyApplication)getApplication()).getAppComponent())
                .build()
                .inject(this);


        userManger.register();


        startActivity(new Intent(this,LoginActivity.class));




    }


}
