package com.cniao5.cniao5dagger2;

/**
 * Created by Ivan on 2016/12/7.
 */

public class Gson {
}
