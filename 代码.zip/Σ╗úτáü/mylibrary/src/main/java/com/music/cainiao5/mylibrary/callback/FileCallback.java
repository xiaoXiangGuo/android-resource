package com.music.cainiao5.mylibrary.callback;

public interface FileCallback {
}
