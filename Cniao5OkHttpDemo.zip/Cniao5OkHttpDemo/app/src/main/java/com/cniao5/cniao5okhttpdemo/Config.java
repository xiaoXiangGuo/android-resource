package com.cniao5.cniao5okhttpdemo;

/**
 * Created by Ivan on 16/10/5.
 */

public class Config {


    public static class API{


        public  static final String  BASE_URL="http://192.168.1.189:5000/";

    }
}
