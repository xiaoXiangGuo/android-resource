package com.cniao5.cniao5dagger2.user;

import android.content.Context;
import android.util.Log;


import com.cniao5.cniao5dagger2.ano.ActivityScope;
import com.cniao5.cniao5dagger2.ano.Release;
import com.cniao5.cniao5dagger2.ano.Test;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;

/**
 * Created by Ivan on 2016/12/1.
 */

@Module
public class UserModule {









    @Provides
    public ApiService provideApiService(OkHttpClient client){



        ApiService apiService =   new ApiService(client);

        return  apiService;

    }

    @Provides
    public UserManger provideUserManger(ApiService apiService){

        return  new UserManger(apiService);
    }


}
