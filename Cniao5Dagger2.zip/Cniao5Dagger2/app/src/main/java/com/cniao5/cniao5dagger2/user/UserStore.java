package com.cniao5.cniao5dagger2.user;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.List;

/**
 * Created by Ivan on 2016/12/1.
 */

public class UserStore {


    private  Context mContext;
    public UserStore(Context context){

        this.mContext = context;

    }
    public void  register(){

        //本地保存数据

    }
}
