package com.music.cainiao5.mylibrary;

import android.content.Context;

import com.music.cainiao5.mylibrary.download.OkDownBuilder;

/**
 * Created by hongkl on 17/8/21.
 */
public class OkDown {
    /**
     * 下载
     *
     * @param context
     * @return
     */
    public static OkDownBuilder init(Context context) {
        return new OkDownBuilder(context);
    }

}
